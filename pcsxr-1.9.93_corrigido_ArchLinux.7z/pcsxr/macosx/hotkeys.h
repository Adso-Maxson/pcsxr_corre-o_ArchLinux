//
//  hotkeys.h
//  Pcsxr
//
//  Created by Nicolas Pepin-Perreault on 12-12-12.
//
//

#ifndef Pcsxr_hotkeys_h
#define Pcsxr_hotkeys_h

void attachHotkeys();
void detachHotkeys();

#endif
