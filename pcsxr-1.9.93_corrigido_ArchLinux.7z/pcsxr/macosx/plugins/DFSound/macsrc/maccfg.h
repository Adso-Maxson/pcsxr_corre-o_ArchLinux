//
//  maccfg.h
//  PeopsSPU
//

#ifndef PeopsSPU_maccfg_h
#define PeopsSPU_maccfg_h

void DoAbout();
long DoConfiguration();
void LoadConfiguration();

#endif
