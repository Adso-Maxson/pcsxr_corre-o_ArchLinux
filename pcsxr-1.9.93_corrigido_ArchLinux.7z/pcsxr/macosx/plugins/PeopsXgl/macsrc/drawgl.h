/* drawgl.h */

unsigned long ulInitDisplay(void);
void CloseDisplay(void);
void BringContextForward(void);
void DoBufferSwap(void);
void SetVSync(GLint myValue);
void BringContextForward(void);
void ChangeWindowMode(void);
void AboutDlgProc();
void DlgProc();
