//
//  MemBadgeView.h
//  Pcsxr
//
//  Created by C.W. Betts on 7/6/13.
//
//

#import <Cocoa/Cocoa.h>

//TODO: also include the memory count in the view as well.
@interface MemBadgeView : NSView

@end
