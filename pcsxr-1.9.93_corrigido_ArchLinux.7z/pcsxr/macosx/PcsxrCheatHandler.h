//
//  PcsxrCheatHandler.h
//  Pcsxr
//
//  Created by C.W. Betts on 8/1/13.
//
//

#import <Foundation/Foundation.h>
#import "PcsxrFileHandle.h"

@interface PcsxrCheatHandler : NSObject <PcsxrFileHandle>

@end
