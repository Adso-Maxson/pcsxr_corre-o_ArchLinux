//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by bladesio1.rc
//
#define IDC_SETS1                       3
#define IDC_SETS2                       4
#define IDOK2                           5
#define IDD_DIALOG1                     130
#define IDD_ABOUT                       130
#define IDD_CFGDLG                      131
#define IDC_XAVOLUME                    1004
#define IDC_ENABXA                      1005
#define IDC_XAPITCH                     1006
#define IDC_XABLOCK                     1007
#define IDC_USETIMER                    1007
#define IDC_CMIXRATE                    1008
#define IDC_USEIRQ                      1008
#define IDC_USEREVERB                   1008
#define IDC_CMODE                       1009
#define IDC_VOLUME                      1009
#define IDC_CFILTER                     1010
#define IDC_IRQWAIT                     1010
#define IDC_CQUALITY                    1011
#define IDC_DEBUGMODE                   1011
#define IDC_CDSOUND                     1012
#define IDC_INTERPOL                    1012
#define IDC_PLAYALWAYS                  1013
#define IDC_RECORDMODE                  1013
#define IDC_IGNOREPITCH                 1014
#define IDC_DISSTEREO                   1014
#define IDC_AMPLIF                      1015
#define IDC_IRQDECODE                   1015
#define IDC_VENVELOPE                   1016
#define IDC_VOL1                        1016
#define IDC_REVERB                      1017
#define IDC_VOL2                        1017
#define IDC_VOL3                        1018
#define IDC_VOL4                        1019
#define IDC_XA                          1133
#define IDC_FREQRESPONSE                1136
#define IDC_DISABLED                    1137
#define IDC_SERVER                      1138
#define IDC_CLIENT                      1139
#define IDC_IP                          1141
#define IDC_EDIT2                       1145
#define IDC_PORT                        1145

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        144
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1146
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
