//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PadSSSPSX.rc
//
#define IDD_DIALOG1                     100
#define IDC_BSELECT                     1000
#define IDC_BL3                         1001
#define IDC_BR3                         1002
#define IDC_BSTART                      1003
#define IDC_BUP                         1004
#define IDC_BRIGHT                      1005
#define IDC_BDOWN                       1006
#define IDC_BLEFT                       1007
#define IDC_BL2                         1008
#define IDC_BR2                         1009
#define IDC_BL1                         1010
#define IDC_BR1                         1011
#define IDC_BTRIANGLE                   1012
#define IDC_BCIRCLE                     1013
#define IDC_BCROSS                      1014
#define IDC_BSQUARE                     1015
#define IDC_BMODE                       1016
#define IDC_BLAX                        1017
#define IDC_BLAY                        1018
#define IDC_BRAX                        1019
#define IDC_BRAY                        1020
#define IDC_ESELECT                     1030
#define IDC_EL3                         1031
#define IDC_ER3                         1032
#define IDC_ESTART                      1033
#define IDC_EUP                         1034
#define IDC_ERIGHT                      1035
#define IDC_EDOWN                       1036
#define IDC_ELEFT                       1037
#define IDC_EL2                         1038
#define IDC_ER2                         1039
#define IDC_EL1                         1040
#define IDC_ER1                         1041
#define IDC_ETRIANGLE                   1042
#define IDC_ECIRCLE                     1043
#define IDC_ECROSS                      1044
#define IDC_ESQUARE                     1045
#define IDC_EMODE                       1046
#define IDC_ELAX                        1047
#define IDC_ELAY                        1048
#define IDC_ERAX                        1049
#define IDC_ERAY                        1050
#define IDC_TABC                        1060
#define IDC_DS2                         1070
#define IDC_VV3                         1071

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1061
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
